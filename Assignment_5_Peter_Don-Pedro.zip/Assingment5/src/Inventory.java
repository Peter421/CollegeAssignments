
public class Inventory {
private String sku;
private Item item;

public Inventory(String sku,Item item) {
	this.sku = sku;
	this.item = item;
	}
@Override
public String toString() {
	return ""+sku+" "+item ;
}
}
