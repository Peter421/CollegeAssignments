// name:Peter Don-Pedro ID:17435402
public class Item implements java.lang.Comparable<Item> {
//item variables
	public String ItemName;
	public double price;
	public int quantity;
	public int amount;
	
	//item constructor
	public Item(String ItemName, int quantity, double price) {
		this.ItemName = ItemName;
		this.price = price;
		this.quantity = quantity;
		
	}
	
	//to string method
	@Override
	public String toString() {
		return " Item Name:"+ItemName+" Price:"+price+" Quantity:"+quantity+"\n";
	}

	//compareto method
	@Override
	public int compareTo(Item o) {
		// TODO Auto-generated method stub
		return Double.compare(this.price,o.price);
	}

	

	
}
