// name:Peter Don-Pedro ID:17435402
public class Test  {

	public static void main(String args[]) {
		//create items and add them to inventory
		Item itm1 = new Item("Apple", 30, 2.50);
		Inventory i1 = new Inventory("1000",itm1);
		
		Item itm2 = new Item("Orange", 40, 2);
		Inventory i2 = new Inventory("1001",itm2 );
		
		Item itm3 = new Item("Milk", 10, 2.39) ;
		Inventory i3 = new Inventory("2001",itm3);
		
		Item itm4 = new Item( "Orange Juice", 20, 1.99) ;
		Inventory i4 = new Inventory("2002",itm4);

		Item itm5 = new Item("Blue Cheese", 10, 2.25) ;
		Inventory i5 = new Inventory("3001",itm5);
		
		Item itm6 = new Item( "Cheddar", 20, 2.79) ;
		Inventory i6 = new Inventory("3002",itm6);

		Item itm7 = new Item( "Chocolate", 40, 2.99) ;
		Inventory i7 = new Inventory("4001",itm7);
		
		Item itm8 = new Item("Candy", 30, 0.99) ;
		Inventory i8 = new Inventory("4002", itm8);

		Item itm9 = new Item( "Beef", 10, 5.00) ;
		Inventory i9 = new Inventory("5001",itm9); 
		
		
		Item itm10 = new Item( "Chicken", 10, 4.00) ;
		Inventory i10 = new Inventory("5002",itm10);
		
		//print original inventory 
		System.out.println("before cart 1");
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		System.out.println(i4);
		System.out.println(i5);
		System.out.println(i6);
		System.out.println(i7);
		System.out.println(i8);
		System.out.println(i9);
		System.out.println(i10);
		
		//create shopping cart
		ShoppingCart cart1 = new ShoppingCart("sarah","07/11/2019");
		cart1.addItem(itm1, 2);
		cart1.addItem(itm2, 5);
		cart1.addItem(itm3, 2);
		cart1.addItem(itm5, 4);
		cart1.addItem(itm8, 25);
		cart1.removeItem(itm8, 5);
		cart1.viewCart();
		
		//inventory after first shopping cart
		System.out.println("after cart 1 and before cart 2");
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		System.out.println(i4);
		System.out.println(i5);
		System.out.println(i6);
		System.out.println(i7);
		System.out.println(i8);
		System.out.println(i9);
		System.out.println(i10);
		
		System.out.println("\n");
		// create second shopping cart
		ShoppingCart cart2 = new ShoppingCart("Derek","08/12/2019");
		cart2.addItem(itm1, 2);
		cart2.addItem(itm2, 5);
		cart2.addItem(itm3, 2);
		cart2.addItem(itm5, 4);
		cart2.addItem(itm6, 3);
		cart2.addItem(itm9, 6);
		cart2.addItem(itm8, 10);
		cart2.addItem(itm7, 10);
		cart2.addItem(itm10, 2);
		cart2.removeItem(itm7, 5);
		cart2.removeItem(itm5, 1);
		
		
		cart2.viewCart();
		//inventory after second shopping cart
		System.out.println("after  cart 2");
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		System.out.println(i4);
		System.out.println(i5);
		System.out.println(i6);
		System.out.println(i7);
		System.out.println(i8);
		System.out.println(i9);
		System.out.println(i10);
		
		
	}

	


	

	
}
