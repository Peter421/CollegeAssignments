// name:Peter Don-Pedro ID:17435402
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShoppingCart /*implements java.lang.Comparable<Item> */{

	private String CustomerName;
	private String date;
	private List<Item> items = new ArrayList();
	private double total;
	
	
	//shopping cart constructor
	public ShoppingCart(String CustomerName, String  date) {
		this.CustomerName= CustomerName;
		this.date = date;
	}
	//method to add item
	public boolean addItem(Item item,int amount) {
		
		if(amount > item.quantity) {
			System.out.println("we only have " +item.quantity+ item.ItemName+"'s available");
		}
		else if(item.quantity == 0) {
		 System.out.println("item is out of stock");
		}
		else 
		item.quantity = item.quantity - amount;
		item.amount = amount;
		return items.add(item);
		
		
	}
	
	//method to remove item
	public int removeItem(Item item,int amount) {
				item.amount -= amount;
				if(item.amount == 0) {
				 items.remove(item);
				}
		item.quantity = item.quantity + amount;
		return item.amount;
	}
	
	//method to search for item
	public void SearchInventory(Item item) {
		
		Collections.sort((List<Item>) items);
	int pos = Collections.binarySearch(items, item);
	}
	
	
	
	//method to view contents of shopping cart
	public void viewCart() {
		
		
		System.out.printf("Name: "+CustomerName +"  "+"Date: "+date +" "+"\n");
		total = 0.0;
		
		for(int i = 0;i<items.size();i++) {
			
		total += items.get(i).amount*items.get(i).price;
		
		double price =items.get(i).amount*items.get(i).price;
		price =  Math.round(price*100);
		System.out.println(items.get(i).amount +" "+items.get(i).ItemName+" "+"�"+price /100);
		}
		total = Math.round(total*100);
		
		System.out.println("total: �"+total / 100);
		total =total/100;
		
	}
	
	
	
}
