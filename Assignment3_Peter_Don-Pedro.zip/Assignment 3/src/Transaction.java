// name:Peter Don-Pedro ID:17435402
public class Transaction {


//variables
	private static int count = 0;
	private int tnumber;
	 String date;
	private String type;
    double amount = 0;
	
    //constructor
	public Transaction(String date, String type, double amount) {
		count++;
		tnumber = count;
		
		this.date = date;
		this.type = type;
		this.amount = amount;
	}
	
	//toString method
	public String toString() {
		return tnumber +"." +' ' + date +' '+ type +":" +' ' + amount;
	}
	
}

