// name:Peter Don-Pedro ID:17435402
public class BankAccount {

	private String name;
	private static int count;
	private int anumber;
	private double balance;
	 Transaction transaction;
	 private double overdraft;
	 
	 //bank account constructor
	 public BankAccount(String name, double balance) {
		 transaction = new Transaction(name, name, balance);
		 count++;
		anumber = count;
		
		this.name = name;
		this.balance = balance;
		
			
	 }
	 
	 //deposit method gets date of deposit and amount that was deposited when transaction was made
	 
 public double deposit(String date, double amnt) {
	 transaction.date = date;
	 transaction.amount = amnt;
	 
	 balance += amnt;
	 return amnt;
 }
 
 //deposit method gets date of withdrawal and amount that was deposited when transaction was made
 public double withdraw(String date, double amnt) {
	 
	 transaction.date = date;
	 transaction.amount = amnt;
	 
	 balance -= amnt;
	 return amnt;
 }
 
 // gets transaction details
 public String getTransactionDetail(Transaction T) {
	return T.toString();
	 
 }
 
 //checks if transaction is invalid,if not returns transaction details
 public String toString() {
	 if( withdraw(transaction.date, transaction.amount) >  balance) {
		 System.out.println("insufficient funds");
		 return "\t";
	 }
	 else 
		 
		 return "Account number:" +anumber+ ' '+ "Name:"+name+' '+"balance:"+ balance +"\n"+ getTransactionDetail(transaction);
 }
}