// name:Peter Don-Pedro ID:17435402
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JOptionPane;


public class Test {
	
	@SuppressWarnings("null")
	public static void main(String args[]) throws IOException {
		Transaction transaction = null;
		String output ="";
		
		 //create transaction array
        Transaction tran[] = new Transaction[3];
        
        Transaction t1 = new Transaction("16/08/2019","Open Account",100.0);
        tran[0] = t1;
        Transaction t2 = new Transaction("22/08/2019","Withdraw",50.0);
        tran[1]= t2;
        Transaction t3 = new Transaction("23/08/2019","Deposit",100.0);
        tran[2] = t3;
//serialize array by writing it to file
        FileWriter fw = new FileWriter("transactions.bin");
        
        for(int i = 0;i < tran.length;i++){
        	
        	fw.write(tran[i] + "\n");
        }
        fw.close();
        
        
       //create bank object
        BankAccount bank = new BankAccount("jenny Lee",200.0);
         bank.getTransactionDetail(t1);
         bank.withdraw(t2.date,50.0);
         bank.deposit(t3.date, t3.amount);
         bank.withdraw("01/09/2019",50.0);
         
         //serialize array by writing it to file
         FileWriter f = new FileWriter("accountdetails.bin");
         f.write(bank + "\n");
         f.close();
         
         //de-serialize and store in String named details and print to console
         String details = "";
         
         FileReader fdr = new FileReader("accountdetails.bin");
         int x;
         while ((x=fdr.read()) != -1) 
             details += ((char) x);
         
         System.out.println(details);
        //print transactions to console
         FileReader fr = new FileReader("transactions.bin");
         int i; 
         while ((i=fr.read()) != -1) 
           System.out.print((char) i); 
         
         // create random access file
         File F = new File("text.txt");
         RandomAccessFile raf =   new RandomAccessFile(F,"rw");
         
         
         
         raf.writeBytes("Would you like to increase your overdraft? Please type Yes/No at the end of the line." );
         
         //append yes/no to end of file
         long length = raf.length();
         raf.setLength(length + 1);
         raf.seek(raf.length());
         raf.writeBytes("yes\n");
         
         //print file
         
         raf =   new RandomAccessFile(F,"r");
         
         String line = raf.readLine();
        
         
        	 System.out.println(line);
         }

        
        
         
	}
	
	

