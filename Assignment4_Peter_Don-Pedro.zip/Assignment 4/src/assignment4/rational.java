// name:Peter Don-Pedro ID:17435402
package assignment4;

import java.math.BigDecimal;
import java.math.MathContext;

public class rational {
private double p;
private double q;
rational r;
//constructor
public rational(double p, double q) {
	this.p = p;
	this.q =q;
	
}

// greatest common multiplier method essential for the  simplification of sums
private double gcm(double p, double q) {
	
	return q == 0 ? p : gcm(q, p % q);
}  

//convert decimal to fraction method
public double fTod(rational r) {
	      
	BigDecimal dvalue = BigDecimal.valueOf(p /r.q);
	
	MathContext m = new MathContext(2); 
	BigDecimal d2p = dvalue.round(m);
     return d2p.doubleValue();
   
    }

//addition method
public rational plus(rational r) {
	double gnm = gcm( this.p*(r.q)+(r.p*(this.q)),this.q*(r.q));
	
	rational n = new rational(( this.p*(r.q)+(r.p*(this.q)))  , this.q*(r.q) );
	System.out.println("("+ p + "/" + q +") " + "+"+ " ("+r.p +"/"+r.q+") " +"= " +n +" =");
  
   return new rational(( this.p*(r.q)+(r.p*(this.q))) /gnm , (this.q*(r.q) / gnm));
}

// multiplication method 
public rational multiply(rational r) {
	double gnm = gcm(this.p*(r.p),this.q*(r.q));
	
	rational n = new rational(this.p*(r.p) , this.q*(r.q));
	System.out.println("("+ p + "/" + q +") " + "x"+ " ("+r.p +"/"+r.q+")" +"=" +n +"="+ " =");
	return new rational((this.p*(r.p)/ gnm) , (this.q*(r.q)/ gnm));
}

//subtraction method
public rational minus(rational r) {
	double gnm = gcm(this.p*(r.q)-(this.q*(r.p)),this.q*(r.q));
	
rational n =  new rational ((this.p*(r.q)-(this.q*(r.p))),this.q*(r.q));

       
       System.out.println("("+ p + "/" + q +") " + "-"+ " ("+r.p +"/"+r.q+") " +" = " +n +" =");
       return new rational(((this.p*(r.q)-(this.q*(r.p))) / gnm),( this.q*(r.q)/ gnm));
}

//division method
public rational divide(rational r) {
	
	double gnm = gcm(this.p*(r.q),this.q*(r.p));
	
	rational n = new rational(this.p*(r.q), this.q*(r.p));
	System.out.println("("+ p + "/" + q +") " + "/"+ " ("+r.p +"/"+r.q+") " +"= " +n +" =");
	 return new rational((this.p*(r.q) / gnm), (this.q*(r.p)/gnm));
	 
}

//toString method
//returns error message if denominator is zero otherwise returns sum
@Override
public String toString() {
	rational r = new rational(p,q);
	//if q is 0 returns error message
	if(q == 0) {
		return "number doesnt exist";
	}
	
	else return  p +"/" + q +" = " +fTod(r)+ "\n";
    
}
}