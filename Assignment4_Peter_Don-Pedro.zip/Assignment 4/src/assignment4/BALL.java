
// name:Peter Don-Pedro ID:17435402 
package assignment4;


//ball enum
public enum BALL {
	BASEBALL(149, 73),
	BASKETBALL(624, 239),
	FOOTBALL(450, 216),
	GOLF(46, 43),
	POOL(156, 60),
	SOFTBALL(180, 97),
	TENNIS(59, 64),
	VOLLEYBALL(260,218);
	
	
	private final double weight;
	private final double diamater;
	//constructor
	BALL(double weight,double diamater){
    this.weight = weight;
	this.diamater = diamater;
	}
	
	//method to return circumference
	public double getCircumference() {
		double radius = diamater * 1/2;
		
		return Math.PI * 2*radius;
	}
	
	//method to return volume
	public double getVolume() {
		double radius = diamater * 1/2;
		double r3 = radius * radius * radius;
		
		return (4.0 / 3.0) * Math.PI  * r3;
	}
//main class
	public static void main(String[] args) {
		
		//loop to print weight and diamater values of each type of ball in enum
		for(BALL b : BALL.values()) {
			System.out.printf("%s \t\t\t%f g \t%f mm \n",b,b.weight,b.diamater);
		}
		
		// testing circumference and volume methods
		System.out.printf("the circumfrance of a %S ball = %f mm \n the volume of a %s = %f mm^3 \n", GOLF,GOLF.getCircumference(),BASEBALL,BASEBALL.getVolume());
		
		//objects of type rational
		rational r = new rational(15.0,1.0);
		rational rf = new rational(40.0,1.0);
		rational r1 = new rational(BASEBALL.weight, BASKETBALL.weight);
		rational r2 = new rational(FOOTBALL.weight, GOLF.weight);
		rational r3 = new rational(POOL.diamater, SOFTBALL.diamater);
		rational r4 = new rational(TENNIS.diamater, VOLLEYBALL.diamater);
		
		System.out.print("\n rationals  \n");
		System.out.print(r1);
		System.out.print(r2);
		System.out.print(r3);
		System.out.print(r4);
		System.out.print("\n");
		
		//carrying out calculations using methods from rational class
		System.out.println(r.divide(rf));
		System.out.println(r1.plus(r2));
		System.out.println( r2.minus(r3));
		System.out.println( r3.multiply(r4));
		System.out.println( r4.divide(r1));
		

		
				
	}
}
